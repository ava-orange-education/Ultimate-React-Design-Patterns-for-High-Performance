import Buttons from "./Buttons"
import Counter from "./Counter"

const Parent = () => {
  return (
    <>
        <Buttons />
        <Counter />
    </>
  )
}

export default Parent