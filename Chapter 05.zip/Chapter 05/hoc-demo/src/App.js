import UserInfoForm from "./components/UserInfoForm";

function App() {
  return (
    <>
      <UserInfoForm />
    </>
  );
}

export default App;
