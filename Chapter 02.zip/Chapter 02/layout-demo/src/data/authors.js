export const authors = [
    {
        name: "Nabendu Biswas",
        age: 42,
        country: "India",
        books: ["TypeScript Basics", "Practical GraphQL"]
    },
    {
        name: "Ami Ganatra",
        age: 36,
        country: "India",
        books: ["Ramayana Unravelled", "Mahabharata Unravelled"]
    },
    {
        name: "Chetan Bhagat",
        age: 45,
        country: "India",
        books: ["400 Days", "Five point someone"]
    }
]