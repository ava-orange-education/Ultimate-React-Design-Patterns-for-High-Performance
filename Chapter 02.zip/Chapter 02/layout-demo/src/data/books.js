export const books = [
    {
        name: "TypeScript Basics",
        pages: 300,
        title: "Nabendu Biswas",
        price: 3500
    },
    {
        name: "Ramayana Unravelled",
        pages: 380,
        title: "Ami Ganatra",
        price: 380
    },
    {
        name: "400 Days",
        pages: 356,
        title: "Chetan Bhagat",
        price: 206
    }
]